termux-setup-storage
cp 'config/game_patch_1.3.0.14924.pak' '/storage/emulated/0/android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/saved/Paks'
clear
echo 'run the game'